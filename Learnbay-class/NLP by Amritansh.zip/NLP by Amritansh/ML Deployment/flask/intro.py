
from flask import Flask, render_template

# The __name__ variable passed to the Flask class is a Python predefined variable, which is set to the name of the module in which it is used
app = Flask(__name__)


@app.route('/')

def hello():
	return "Hello World !!"
	# return render_template("index.html")


if __name__ == "__main__":
	app.run(debug=True)
